
# Power BI Build Instructions — Cognifyz Data Analysis Dashboard
Prepared for: **Neutral Professional (Blue/Gray) theme**

This package contains cleaned data and visual assets to build a single-page (or multi-page) Power BI report replicating the analyses performed.
Follow the steps below in Power BI Desktop to recreate the dashboard. Exact DAX measures and visual settings are provided.

---
## Files included in this package
- `Dataset_cleaned_for_PowerBI.csv` — cleaned dataset ready to import.
- `analysis_summary.json` — structured summary of analyses.
- `cuisine_counts.csv` — counts by cuisine.
- `price_range_distribution.csv` — price range counts & percentages.
- `top_cuisine_combinations.csv` — top cuisine-combination strings.
- `geo_locations.png` — exported longitude/latitude scatter plot (optional background).
- `possible_chains.csv` — detected chains by repeated restaurant name (if present).
- `Cognifyz_Data_Analysis_Report.pdf` — full report (for reference).

---
## Recommended Report Structure
Create a **4-page** report in Power BI Desktop (or a single page with sections):

Page 1 — Overview (KPIs)
- KPIs: Total Restaurants, Distinct Cities, Average Rating, % Online Delivery
- Visuals: Card visuals for each KPI; a multi-row card for small metadata.
- Use a slicer for City and Price range (single-select or multi-select).

Page 2 — Level 1 Insights
- Bar chart: Top Cuisines by Count (use `cuisine_counts.csv` or split `Cuisines` into rows)
- Table: Top Cities with number of restaurants and average rating (use `City` and `Aggregate rating`)
- Column chart: Price Range distribution (use `Price range`/`Average Cost for two`)
- Clustered bar: Avg Rating (With Online Delivery vs Without).

Page 3 — Level 2 Insights
- Map (Map or ArcGIS Map): Latitude vs Longitude. Use `Latitude` and `Longitude`. Set bubble size to `Votes`.
- Bar chart: Top Cuisine Combinations (use `top_cuisine_combinations.csv`)
- Table: Possible Chains with counts and average rating (join to dataset on name).

Page 4 — Level 3 Insights
- Scatter chart: Votes (X) vs Aggregate rating (Y). Add trend line (Analytics pane → Trend line).
- Table: Top 10 highest votes and bottom 10 lowest votes.
- Stacked column or 100% stacked column: Price range vs % Online Delivery and % Table Booking by price.

---
## Data Modeling Tips
1. Import `Dataset_cleaned_for_PowerBI.csv` as a single table named `Restaurants`.
2. If `Cuisines` is a comma-separated field, create a split table:
   - In Power Query: Duplicate `Restaurants` query → Split `Cuisines` column by delimiter (comma) into rows → Trim whitespace → Remove blanks → Rename as `Cuisines_Rel` with columns `Restaurant ID`, `Cuisine`.
   - Load both `Restaurants` and `Cuisines_Rel`. Create a one-to-many relationship: `Restaurants[Restaurant ID]` → `Cuisines_Rel[Restaurant ID]`.
3. Ensure `Latitude` and `Longitude` are numeric. `Aggregate rating` and `Votes` should be numeric too.
4. Create a Price numeric column if needed: `PriceNum = VALUE( [Price range] )` or parse `Average Cost for two` to numeric.

---
## Suggested DAX Measures (copy into New Measure)
Total Restaurants =
```
Total Restaurants = DISTINCTCOUNT(Restaurants[Restaurant ID])
```

Distinct Cities =
```
Distinct Cities = DISTINCTCOUNT(Restaurants[City])
```

Average Rating (overall) =
```
Average Rating = AVERAGE(Restaurants[Aggregate rating])
```

% Online Delivery =
```
Pct Online Delivery = 
VAR _total = COUNTROWS(Restaurants)
VAR _online = CALCULATE(COUNTROWS(Restaurants), FILTER(Restaurants, 
    LOWER( Restaurants[Has Online delivery] ) IN {"yes","1","true","y","available","t","online"} ))
RETURN DIVIDE(_online, _total, 0)
```

Average Rating — With Online Delivery =
```
Avg Rating Online = 
CALCULATE( AVERAGE(Restaurants[Aggregate rating]), 
    FILTER(Restaurants, LOWER(Restaurants[Has Online delivery]) IN {"yes","1","true","y","available","t","online"} ) )
```

Average Rating — Without Online Delivery =
```
Avg Rating Offline = 
CALCULATE( AVERAGE(Restaurants[Aggregate rating]), 
    FILTER(Restaurants, NOT( LOWER(Restaurants[Has Online delivery]) IN {"yes","1","true","y","available","t","online"} ) ) )
```

Top N Cuisines (using Cuisine table)
```
Cuisine Count = COUNTROWS(RELATEDTABLE(Cuisines_Rel))
```

% Online by Price (example)
```
Pct Online by Price = 
DIVIDE( CALCULATE( COUNTROWS(Restaurants), FILTER(Restaurants, LOWER(Restaurants[Has Online delivery]) IN {"yes","1","true","y","available","t","online"} ) ),
        COUNTROWS(Restaurants), 0)
```

Correlation (Votes vs Rating) — approximate (requires creating measures)
Power BI doesn't have CORR directly; use this approach:
```
Votes Rating Covariance = 
VAR x = AVERAGE(Restaurants[Votes])
VAR y = AVERAGE(Restaurants[Aggregate rating])
VAR cov = AVERAGEX( Restaurants, (Restaurants[Votes]-x) * (Restaurants[Aggregate rating]-y) )
RETURN cov
```
Then compute standard deviations and divide to get correlation if needed.

---
## Visual Formatting & Colors (Neutral Professional)
Use this palette (blue / gray):
- Primary blue: `#1F77B4`
- Secondary blue: `#4A90E2`
- Accent gray: `#6E7783`
- Light background: `#F4F6F8`
- Dark text: `#111827`

Fonts: Segoe UI or Arial. Use consistent padding and card sizes.

---
## Visual Interaction Recommendations
- Make City and Cuisine slicers sync across pages.
- Add tooltip pages to show extra details for each restaurant (address, cuisines, votes, average rating).
- Use bookmarks to create a "presentation mode" or report landing toggle (Overview vs Deep Dive).

---
## Exporting & Sharing
- Save file as `.pbix` in Power BI Desktop.
- For sharing without Power BI Service, export to PDF (File → Export → PDF) or publish to Power BI Service for interactive sharing.

---
## If you want, I can also:
- Provide order-independent cuisine combinations (merged sets) CSV.
- Generate ready-to-paste DAX for any extra KPI you need.
- Produce a single `.pbix` file — I cannot create `.pbix` directly inside this environment, but following this guide in Power BI Desktop will reproduce the full dashboard quickly.

---
Prepared automatically from the dataset analysis. If you'd like, I can now package these files into a ZIP (done) and provide the download link.
